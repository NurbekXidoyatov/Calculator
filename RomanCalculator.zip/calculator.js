function calculator(expression) {
  // Regular expression to match valid expressions (two numbers and an operator)
  const regex =
    /^((100|[0-9]{1,2})|I|II|III|IV|V|VI|VII|VIII|IX|X) ([+\-*\/]) ((100|[0-9]{1,2})|I|II|III|IV|V|VI|VII|VIII|IX|X)$/;

  // Check if expression matches the valid format
  if (!regex.test(expression)) {
    throw new Error("Invalid expression format!");
  }

  // Split the expression into operands and operator
  const [operand1, operator, operand2] = expression.split(" ");

  // Convert operands to numbers (Arabic or Roman)
  const num1 = convertRomanToNumber(operand1) || parseInt(operand1);
  const num2 = convertRomanToNumber(operand2) || parseInt(operand2);

  // Check if operands are in valid range (1-10) and not zero
  if (num1 < 1 || num1 > 10 || num2 < 1 || num2 > 10) {
    throw new Error("Operands must be between 1 and 10!");
  }

  // Check if operands are both Arabic or both Roman
  if (isNaN(operand1) !== isNaN(operand2)) {
    throw new Error("Operands must be either both Arabic or both Roman!");
  }

  // Perform calculation based on operator
  let result;
  switch (operator) {
    case "+":
      result = num1 + num2;
      break;
    case "-":
      result = num1 - num2;
      break;
    case "*":
      result = num1 * num2;
      break;
    case "/":
      result = Math.floor(num1 / num2); // Get integer part of division
      break;
  }

  // (V - V => "")
  if (result === 0 && isNaN(operand1) && isNaN(operand2) ) {
    return "";
  }

 

  if (result < 1 && isNaN(operand1) && isNaN(operand2)) {
    return "";
  } 
  if (isNaN(operand1) && isNaN(operand2)) {
    return convertArabicToRoman(result);
  }

  // Return string representation of the result (integer)
  return result.toString();
}

// Function to convert Roman numeral to number (handles up to X)
function convertRomanToNumber(roman) {
  const map = {
    I: 1,
    II: 2,
    III: 3,
    IV: 4,
    V: 5,
    VI: 6,
    VII: 7,
    VIII: 8,
    IX: 9,
    X: 10,
  };
  let sum = 0;
  for (let i = 0; i < roman.length; i++) {
    const current = map[roman[i]];
    const next = map[roman[i + 1]];
    if (current < next && i < roman.length - 1) {
      sum += next - current;
      i++; // Skip next character if subtraction
    } else if (current !== undefined) {
      sum += current;
    } else {
      return null; // Return null for invalid Roman numerals
    }
  }
  return sum;
}
// Function to convert number to Roman numeral (handles up to X)
function convertArabicToRoman(num) {
  const rules = {
    M: 1000,
    CM: 900,
    D: 500,
    CD: 400,
    C: 100,
    XC: 90,
    L: 50,
    XL: 40,
    XXX: 30,
    XX: 20,
    X: 10,
    IX: 9,
    V: 5,
    IV: 4,
    I: 1,
  };

  let res = "";
  const romans = Object.keys(rules);

  for (let i = 0; i < romans.length; ++i) {
    const val = rules[romans[i]];

    while (num >= val) {
      num -= val;
      res += romans[i];
    }
  }
  return res;
}

module.exports = calculator; // Не трогайте эту строчку